<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Message extends CI_Controller {
    
        

	public function requesting_message_successfully()
	{
			
            $data ['message'] ='<p class="center">Thank you for requesting Quotes.</p><br/>
                                    You should receive an email within 48 hours with the details
                                    <br/>
                                    of the dentists who are ready to offer you at least 25% off
                                    <br/>
                                    your dental treatment.<br/><br/>
                                    if you do not receive this email, please donlt forger to check your junk box. Have a great day,
                                    <br/><br/>
                                    The Nanatharana Team
                                    ';
            
			  $data['title'] = 'Message Successfully';	
			$this->load->view('mesages_success', $data);
		
		
	}
        
        public function sign_up_message_successfully()
	{
			
            $data ['message'] ='<p class="center">Thank for you registration!</p><br/>
                                   
Verification email successfully sent. Please confirm your email address.
                                   
                                    
                                    ';
            
			  $data['title'] = 'Message Successfully';	
			$this->load->view('messages/mesages_success', $data);
		
		
	}
        
         public function already_activated()
	{
			
            $data ['message'] ='<p class="center">Your account already activated</p><br/>
                                   

                                    ';
            
			  $data['title'] = 'Message Successfully';	
			$this->load->view('message_successfully', $data);
		
		
	}
        
         public function activated_successfully()
	{
			
            $data ['message'] ='<p class="center">Your account has been activated successfully </p><br/>
                                   
please <a href="'.base_url().'site/practitioner_login" >click here </a> to login
                                    ';
            
			  $data['title'] = 'Message Successfully';	
			$this->load->view('message_successfully', $data);
		
		
	}
        
        
         public function success_fp()
	{
			
            $data ['message'] ='<p class="center">Password Reset link has been sent your email account please check. </p><br/>
                                   

                                    ';
            
			  $data['title'] = 'Message Successfully';	
			$this->load->view('message_successfully', $data);
		
		
	}
        
        
         public function updatepassword_successfully()
	{
			
             $data ['message'] ='<p class="center">Your password has been updated successfully </p><br/>
                                   
please <a href="'.base_url().'site/practitioner_login" >click here </a> to login';
            
			  $data['title'] = 'Message Successfully';	
			$this->load->view('message_successfully', $data);
		
		
	}
        
         public function mesages_success_invoice()
	{
			
            $data ['message'] ='<p class="center">Invoice has been sent successfully<br/>
                                   
 <a href="'.base_url().'site/my_bids" >Back to My bids </a></p>' ;
            
			  $data['title'] = 'Message Successfully';	
			$this->load->view('message_successfully', $data);
		
		
	}
        
        
        
        
        public function mesages_success_contact()
	{
			
            $data ['message'] ='<p class="center">Thanks for contacting us, 
                we will reply to you as soon as possible..</p><br/>' ;
            
			  $data['title'] = 'Message Successfully';	
			$this->load->view('message_successfully', $data);
		
		
	}
	
	
	
	public function message_error()
	{
		
	
			$data['title'] = 'Error Message';		
								

			$data ['message'] ='Opps Errors please try agine!';
		
			
			
			$this->load->view('mesages_errors', $data);
			
		
		
	}
        
        public function message_error_cart_empty()
	{
		
	
			$data['title'] = 'Error Message';		
								

			$data ['message'] ='Your cart is empty! <a href="'.base_url().'site/practitioner_profile"> Go back to my profile</a>';
		
			
			
			$this->load->view('mesages_errors', $data);
			
		
		
	}
        
        public function addtocart()
	{
		
	
			$data['title'] = 'Error Message';		
								

			$data ['message'] ='This Item Already added';
		
			
			
			$this->load->view('mesages_errors', $data);
			
		
		
	}
        
       
        
        public function contact_us()
	{
		
	
			$data['title'] = 'Contact Us'	;		
			$data['page_title'] = 'Contact Us'	;						

			
		
			
			
			$this->load->view('page/contact_us', $data);
			
		
		
	}
        
         public function about_us()
	{
		
	
			$data['title'] = 'About Us'	;		
			$data['page_title'] = 'About Us'	;						

			
		
			
			
			$this->load->view('page/about_us', $data);
			
		
		
	}
	
	
	public function login()
	{
		if($this->session->userdata('is_logged_in'))
			{
					
			
			$this->load->view('admin_dashboard');
						
						
			}
		else {
		
			$this->load->view('login');
			}
	}
	
	
	
	public function login_attempt()
	{
	
		$this->load->library('form_validation');		
		$this->form_validation->set_rules('user_id', 'User Id', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
	
	
		if($this->form_validation->run())	{	
		
				
		   $this->load->model('main_model');
		   $this->main_model->login_check();
			
		   return true;
					
					
		
		}
		
		else
		{
			$this->load->view('login');
		}
	}
	
	
	public function logout(){
		
		$lonin_user = $this->input->post('login_user_id');
		// manager aprovel for logout.
		
		
		
			
		
		$this->session->sess_destroy();
		redirect('main/login');
		
		}
		
	
	public function select_product()
	{
		$product_id = $this->input->post('cinputname_id');
		$this->load->model('main_model');
        $query= $this->main_model->select_product($product_id);
						
		
		
		
	}


	public function edit_product_db()
	{
		$product_id = $this->input->post('product_id');
		$products_specifications = $this->input->post('products_specifications');
		
		$this->load->model('main_model');
        $query= $this->main_model->edit_product_db($product_id, $products_specifications);
						
		
		
		
	}	
	
	
	
	 public function deleteiitemcode()
	{
		$id = $this->input->get('id');
                $this->db->where('id' , $id);
	        $this->db->delete('addcode');
                
                
                
			 
	}
        
    
    public function request_quotes_add(){
               $rf = date("ymdHis");
       $this->load->helper(array('form', 'url'));
        $upname = $rf.$_FILES['uploadfile']['name'];
        $upname = strtr($upname, 'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ', 'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy');

// remplacer les caracteres autres que lettres, chiffres et point par _

         $upname = preg_replace('/([^.a-z0-9]+)/i', '_', $upname);

        //Your upload directory, see CI user guide
        $config['upload_path'] = './upload';  
        $config['allowed_types'] = 'gif|jpg|png|JPG|GIF|PNG';
        $config['max_size'] = '20000';
        $config['file_name'] = $upname;
        
        $this->load->library('upload',$config);
        
        //$this->upload->do_upload('uploadfile');
        
         echo $this->upload->display_errors();
         if (!$this->upload->do_upload('uploadfile')) {
                $error = array('error' => $this->upload->display_errors());

               // print_r($error) ;
            return false;
        } else {
            $this->load->model('site_model');
			$this->site_model->request_quotes_add($upname);

            return true;
        }
                    
		  				
		
        
        
        
        
    }
        
	public function success_payment()
	{
			
            $data ['message'] ='<p class="center">Your payment has been paid successfully! </p><br/>
                                   
			please <a href="'.base_url().'site/my_bids" >click here </a> 
                                    ';
            
			  $data['title'] = 'Message Successfully';	
			$this->load->view('message_successfully', $data);
		
		
	}
	
	public function allReadyEnroll()
	{
			
            if($this->session->userdata('is_logged_in') == TRUE )
			{
		
		
			$this->load->model('students_model');		  
			$result = $this->students_model->sutdent_profile();
			$data['userdatas'] = $result['userdatas'];
			$data['users'] = $result['users'];
			
			
			$data['title'] = 'Error Message';		
								

			$data ['message'] ='You already enrolled this quiz';
			$data ['url'] ='enroll/index';
			$data ['btn_name'] ='Enrollment list';
		
			
			
			$this->load->view('messages/mesages_errors', $data);
			}
			
			else {
			redirect(base_url().'users/index');
			
			}
		
	}
	
	
	public function topup_success()
	{
			
            if($this->session->userdata('is_logged_in') == TRUE )
			{
		
		
			$this->load->model('students_model');		  
			$result = $this->students_model->sutdent_profile();
			$data['userdatas'] = $result['userdatas'];
			$data['users'] = $result['users'];
			
			
			$data['title'] = 'Success Message';		
								

			     $data['message'] ="You credit has been successfully added";
					$data['btn_name'] ="My Credits";
					$data['url'] ="credits/index";
					$this->load->view('messages/mesages_success_cz', $data);
		
			
			
			
			}
			
			else {
			redirect(base_url().'users/index');
			
			}
		
	}
	
	
	public function payment_success()
	{
			
            if($this->session->userdata('is_logged_in') == TRUE )
			{
		
		
			$this->load->model('students_model');		  
			$result = $this->students_model->sutdent_profile();
			$data['userdatas'] = $result['userdatas'];
			$data['users'] = $result['users'];
			
			
			$data['title'] = 'Success Message';		
								

			   $data['message'] ="You payment has been successfully paid";
					$data['btn_name'] ="Enrollment List";
					$data['url'] ="enroll/index";
					$this->load->view('messages/mesages_success_cz', $data); 
					
		
			
			
			
			}
			
			else {
			redirect(base_url().'users/index');
			
			}
		
	}
	
	public function allReadyUsedEmail()
	{
			
            if($this->session->userdata('is_logged_in') !== TRUE )
			{
		
		
			$this->load->model('students_model');		  
			$result = $this->students_model->sutdent_profile();
			$data['userdatas'] = $result['userdatas'];
			$data['users'] = $result['users'];
			
			
			$data['title'] = 'Error Message';		
								

			$data ['message'] ='The email address you entered is already in use';
			$data ['url'] ='users/registration';
			$data ['btn_name'] ='Try Again';
		
			
			
			$this->load->view('messages/mesages_errors', $data);
			}
			
			else {
			redirect(base_url().'users/index');
			
			}
		
	}
	
	
	
	
}

