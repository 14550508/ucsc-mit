<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<?php $this->load->view('tpl/site_head'); ?>
<?php $this->load->view('tpl/site_menu'); ?>

<?php //$this->load->view('tpl/slideshow'); ?>

<div class="container">
    <div class="row">
        <!--feature start-->
        <div class="text-center feature-head">
            <h1>About Nanatharana</h1>
            <p>futuristic learning is here</p>
        </div>
      
       
       
        <!--feature end-->
    </div>
    
        
</div>

<!--property start-->
<div class="property gray-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-sm-6 text-center">
                <iframe width="560" height="315" src="//www.youtube.com/embed/a9q0-7bRQh4" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="col-lg-6 col-sm-6">
                <p>Nanatharana was founded in 2011 with objective of providing a platform to do MCQs online. Subsequently, nanatharana has developed itself to become one of the leading activity based e-learning websites in the world which provides many facilities for its 20K plus users.  
Nanatharana mainly focuses the students who are incapable of finding proper educational materials such as model papers, lessons, etc. It provides-learning facilities.</p> 


<h3>Our Mission</h3>
<p>Our is to become the leading activity based e-learning website in the world by 2018</p>

<h3>Our Vision</h3>
<p>Using e-based learning techniques to create a better educational system and thereby create a better world of proficient individuals.</p>

                
            </div>
        </div>
    </div>
</div>
<!--property end-->




<!--parallax start-->
<section class="parallax1">
    <div class="container">
        <div class="row">
            <h1>“You are always a student, never a master. You have to keep moving forward”</h1>
        </div>
    </div>
</section>
<!--parallax end-->

<div class="container">
    <!--clients start-->
    <div class="clients">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    
                </div>
            </div>
        </div>
    </div>
    <!--clients end-->
</div>

<!--container end-->

<?php $this->load->view('tpl/site_footer'); ?>