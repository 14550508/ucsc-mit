<?php  $this->load->view('tpl/head'); ?>
 
<body class="">
    
 <section id="container">
     <?php 
	 
	 $this->load->view('admin/admin_menu');
	 ?>

      <?php $this->load->view('tpl/ads_bar'); ?>


   <!--main content start-->

      <!--main content end-->
<?php $this->load->view('tpl/online_friends'); ?>  
      
<?php  $this->load->view('tpl/footer'); ?>
      
   <?php  $this->load->view('tpl/js/main_js'); ?>
   
    <!--script for this page-->
    <script src="<?php echo base_url();?>template/nanatharana/js/sparkline-chart.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/easy-pie-chart.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/count.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/jquery.customSelect.min.js" ></script>
        <script>

        //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true,
			  autoPlay:true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>
  </body>
</html>