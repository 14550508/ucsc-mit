<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Chamara">
    <meta name="keyword" content="e learning, AL pass papers, OL pass papaers, Organic transformation, sri lanka education">
    <link rel="shortcut icon" href="img/favicon.png">

    <?php
    $NApagetitle='';
        if ($NApagetitle !='')
            {
      ?>
    <title><?php echo $NApagetitle; ?></title>
    <?php 
            }else
                { 
    ?>
    
        <title>Nanatharana</title>
    <?php 
                }
    ?>
    

    <!-- Bootstrap core CSS -->
    
     <link href="<?php echo base_url();?>template/nanatharana/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>template/nanatharana/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo base_url();?>template/nanatharana/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url();?>template/nanatharana/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>template/nanatharana/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="<?php echo base_url();?>template/nanatharana/js/html5shiv.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/respond.min.js"></script>
    <![endif]-->
    
    
    
    
    
    
    <link href="<?php echo base_url();?>template/nanatharana/site/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>template/nanatharana/site/css/theme.css" rel="stylesheet">
    <link href="<?php echo base_url();?>template/nanatharana/site/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo base_url();?>template/nanatharana/site/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url();?>template/nanatharana/site/css/flexslider.css"/>
    <link href="<?php echo base_url();?>template/nanatharana/site/assets/bxslider/jquery.bxslider.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>template/nanatharana/site/assets/fancybox/source/jquery.fancybox.css" rel="stylesheet" />

    <link rel="stylesheet" href="<?php echo base_url();?>template/nanatharana/site/assets/revolution_slider/css/rs-style.css" media="screen">
    <link rel="stylesheet" href="<?php echo base_url();?>template/nanatharana/site/assets/revolution_slider/rs-plugin/css/settings.css" media="screen">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url();?>template/nanatharana/site/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>template/nanatharana/site/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo base_url();?>template/nanatharana/site/js/html5shiv.js"></script>
      <script src="<?php echo base_url();?>template/nanatharana/site/js/respond.min.js"></script>
    <![endif]-->
  </head>


