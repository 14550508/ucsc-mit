 <script src="<?php echo base_url();?>template/nanatharana/js/jquery.js"></script>

    <script src="<?php echo base_url();?>template/nanatharana/js/bootstrap.min.js"></script>   

    <script src="<?php echo base_url();?>template/nanatharana/js/jquery-ui-1.9.2.custom.min.js"></script>  
  <script src="<?php echo base_url();?>template/nanatharana/js/respond.min.js" ></script>


<script src="<?php echo base_url();?>template/nanatharana/validation/js/formValidation.js"></script>
<script src="<?php echo base_url();?>template/nanatharana/validation/js/formValidation.min.js"></script>

<script src="<?php echo base_url();?>template/nanatharana/validation/js/framework/bootstrap.js"></script>
 
