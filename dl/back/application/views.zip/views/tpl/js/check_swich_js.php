<!--custom switch-->
  <script src="<?php echo base_url();?>template/nanatharana/js/bootstrap-switch.js"></script>
  <!--custom tagsinput-->
  <script src="<?php echo base_url();?>template/nanatharana/js/jquery.tagsinput.js"></script>
  <!--custom checkbox & radio-->
  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/js/ga.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-daterangepicker/date.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-daterangepicker/daterangepicker.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/ckeditor/ckeditor.js"></script>
