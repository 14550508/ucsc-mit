<script src="<?php echo base_url();?>template/nanatharana/js/jquery.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>template/nanatharana/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo base_url();?>template/nanatharana/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/jquery.scrollTo.min.js"></script>
	  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/jquery.nicescroll.js" type="text/javascript"></script>
	<script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/jquery.sparkline.js" type="text/javascript"></script>
	<script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/owl.carousel.js" ></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/jquery.customSelect.min.js" ></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/respond.min.js" ></script>
	
	<script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/jquery-multi-select/js/jquery.multi-select.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/jquery-multi-select/js/jquery.quicksearch.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
  <script type="text/javascript" src="<?php echo base_url();?>template/nanatharana/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>  

    <!--right slidebar-->
    <script src="<?php echo base_url();?>template/nanatharana/js/slidebars.min.js"></script>

    <!--common script for all pages-->
    <script src="<?php echo base_url();?>template/nanatharana/js/common-scripts.js"></script>
	   <script src="<?php echo base_url();?>template/nanatharana/js/advanced-form-components.js"></script>
	   
	   <!-- validation  -->
	    <script src="<?php echo base_url();?>template/nanatharana/validation/js/formValidation.js"></script>
	<script src="<?php echo base_url();?>template/nanatharana/validation/js/formValidation.min.js"></script>
	   
	   
	   