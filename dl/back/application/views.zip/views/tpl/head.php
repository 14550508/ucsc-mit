<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Chamara">
    <meta name="keyword" content="e learning, AL pass papers, OL pass papaers, Organic transformation, sri lanka education">
    <link rel="shortcut icon" href="img/favicon.png">

    <?php
    $NApagetitle='';
        if ($NApagetitle !='')
            {
      ?>
    <title><?php echo $NApagetitle; ?></title>
    <?php 
            }else
                { 
    ?>
    
        <title>Nanatharana</title>
    <?php 
                }
    ?>
    

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>template/nanatharana/css/slidebars.css" rel="stylesheet">
     <link href="<?php echo base_url();?>template/nanatharana/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>template/nanatharana/css/bootstrap-reset.css" rel="stylesheet">
	
	<link href="<?php echo base_url();?>template/nanatharana/validation/css/formValidation.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>template/nanatharana/validation/css/formValidation.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo base_url();?>template/nanatharana/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url();?>template/nanatharana/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>template/nanatharana/css/style-responsive.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>template/nanatharana/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <link rel="stylesheet" href="<?php echo base_url();?>template/nanatharana/css/owl.carousel.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>template/nanatharana/assets/bootstrap-fileupload/bootstrap-fileupload.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>template/nanatharana/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>template/nanatharana/assets/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>template/nanatharana/assets/bootstrap-timepicker/compiled/timepicker.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>template/nanatharana/assets/bootstrap-colorpicker/css/colorpicker.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>template/nanatharana/assets/bootstrap-daterangepicker/daterangepicker-bs3.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>template/nanatharana/assets/bootstrap-datetimepicker/css/datetimepicker.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>template/nanatharana/assets/jquery-multi-select/css/multi-select.css" />


    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="<?php echo base_url();?>template/nanatharana/js/html5shiv.js"></script>
    <script src="<?php echo base_url();?>template/nanatharana/js/respond.min.js"></script>
    <![endif]-->
  </head>


