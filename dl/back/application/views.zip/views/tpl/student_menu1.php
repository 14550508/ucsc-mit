 <header class="header white-bg">
          
               <header class="header white-bg">
         
          <!--logo start-->
          <a href="<?php echo base_url();?>" class="logo" ><img src="<?php echo base_url(); ?>img/logo1.png"/></a>
          <!--logo end-->
                   <div class="top-nav ">
              <ul class="nav pull-right top-menu">
                  <li>
                      <input type="text" class="form-control search" placeholder="Search">
                  </li>
                  <!-- user login dropdown start-->
                 
                  <!-- user login dropdown end -->
                 
              </ul>
          </div>
      </header>
      <!--header end-->
      
         
      </header>
      <!--header end-->