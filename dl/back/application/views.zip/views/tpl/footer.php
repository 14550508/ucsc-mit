
  <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
              <?php echo date('Y'); ?> &copy; NANATHARANA (PVT) LTD.
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->


 
 
 
 
