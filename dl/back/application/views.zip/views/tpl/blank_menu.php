 <header class="header white-bg">
          
          <!--logo start-->
          <a href="<?php echo base_url(); ?>" class="logo" >NANA<span>THARANA</span></a>
          <!--logo end-->
      
         
      </header>
      <!--header end-->