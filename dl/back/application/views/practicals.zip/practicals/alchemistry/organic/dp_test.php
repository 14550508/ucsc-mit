<?php  $this->load->view('tpl/head'); ?>
</head>
<body class="">
    <?php //echo $this->session->userdata('userid'); ?>
 <section id="container" class="sidebar-closed">
       <section id="main-content">
          <section class="wrapper">
              
                <div class="draggable_ans">


                </div>


              
                <div class="droppable_ans">



                </div>
              
              
          </section>
       </section>
     
 </section>